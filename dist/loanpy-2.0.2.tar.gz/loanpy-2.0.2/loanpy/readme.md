# Version 2.0 is on its way (for Python 3.9)

Improvements since version 1.0:

- module sanity.py to evaluate results
- solid unit and integration tests
- phontactic repairs
- data driven loanword adaptations
- based on cldf data standard
